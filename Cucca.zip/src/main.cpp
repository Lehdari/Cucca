#include "../include/UnitTests/UnitTests.hpp"


#define GLEW_STATIC


int main(void) {
    return unitTest();
}
