#include "../../include/UnitTests/UnitTest2.hpp"


#if CURRENT_TEST == 2


int unitTest(void) {
    Event<TestEvent1> e1();
    Event<TestEvent2> e2();
    return 0;
}


#endif // CURRENT_TEST
