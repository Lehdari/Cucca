#include "../../include/Core/EventBase.hpp"


using namespace Cucca;


int Cucca::EventBase::getEventType(void) const {
    return eventType_;
}
