/**
    Cucca Game Engine - GraphicsExtensions - HeightMap.hpp

    This file is subject to the terms and conditions defined in
    file 'LICENSE.txt', which is part of this source code package.

    @version    0.1
    @author     Miika Lehtim�ki
    @date       2015-02-03
**/


#ifndef CUCCA_GRAPHICSEXTENSIONS_HEIGHTMAP_HPP
#define CUCCA_GRAPHICSEXTENSIONS_HEIGHTMAP_HPP


#include "../../include/Core/Resource.hpp"

#include <SFML/Graphics/Image.hpp>


namespace Cucca {

    //  Resource
    CUCCA_RESOURCE(HeightMap) {
    public:
        //  Resource init and destroy template member functions
        CUCCA_RESOURCE_INIT_DESTROY

        void fillAttributeVectors(unsigned segmentX,
                                  unsigned segmentY,
                                  std::vector<std::array<float, 4>>& positions,
                                  std::vector<std::array<float, 3>>& texCoords,
                                  std::vector<std::array<float, 3>>& normals,
                                  std::vector<unsigned>& indices);

        unsigned getNumXSegments(void) const;
        unsigned getNumYSegments(void) const;
        float getSegmentXSize(void) const;
        float getSegmentYSize(void) const;
        float getOffsetX(void) const;
        float getOffsetY(void) const;

    private:
        sf::Image major_;
        unsigned numXSegments_;
        unsigned numYSegments_;
        unsigned segmentXResolution_;
        unsigned segmentYResolution_;
        float segmentXSize_;
        float segmentYSize_;
        float offsetX_;
        float offsetY_;
    };

}; // namespace Cucca


#endif // CUCCA_GRAPHICSEXTENSIONS_HEIGHTMAP_HPP
