/**
    Cucca Game Engine - Core - Binary_File.hpp

    This file is subject to the terms and conditions defined in
    file 'LICENSE.txt', which is part of this source code package.


    This file is a resource initialization file.
    It specifies BinaryInitInfo_File struct and Binary init
    and destroy member function template specializations for
    initializing Binary resources from external files.


    @version    0.1
    @author     Miika Lehtim�ki
    @date       2015-02-04
**/


#ifndef CUCCA_CORE_BINARY_FILE_HPP
#define CUCCA_CORE_BINARY_FILE_HPP


#include "ResourceManager.hpp"
#include "Binary.hpp"


namespace Cucca {

    /// Initialization info struct
    struct BinaryInitInfo_File : public ResourceInitInfoBase {
        std::string fileName;
    };


    /// Resource init and destroy template member function specializations
    template<>
    void Binary::init<BinaryInitInfo_File>(const BinaryInitInfo_File& initInfo,
                                          const std::vector<ResourceId>& initResources,
                                          const std::vector<ResourceId>& depResources,
                                          ResourceManager<ResourceId>* resourceManager) {
        FILE* file = fopen(initInfo.fileName.c_str(), "rb");
        if (file) {
            if (fseek(file, 0, SEEK_END)) {
                fclose(file);
                throw "Binary: error seeking end of file"; // TODO_EXCEPTION: throw a proper exception
            }

            size_ = ftell(file);

            if (fseek(file, 0, SEEK_SET)) {
                fclose(file);
                throw "Binary: error seeking beginning of file"; // TODO_EXCEPTION: throw a proper exception
            }

            buffer_ = new char[size_ + 1]; // TODO_ALLOCATOR
            fread(buffer_, sizeof(char), size_, file);
            buffer_[size_] = '\0';

            fclose(file);
        }
        else
            throw "Binary: unable to open file " + initInfo.fileName; // TODO_EXCEPTION: throw a proper exception
    }

    template<>
    void Binary::destroy<BinaryInitInfo_File>(void) {
        if (buffer_) {
            delete[] buffer_;
            buffer_ = nullptr;
            size_ = 0;
        }
    }

} // namespace Cucca


#endif // CUCCA_CORE_BINARY_FILE_HPP
