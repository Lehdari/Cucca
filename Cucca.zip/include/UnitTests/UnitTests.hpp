#ifndef CUCCA_UNITTESTS_UNITTESTS_HPP
#define CUCCA_UNITTESTS_UNITTESTS_HPP


#define CURRENT_TEST 3


#include "UnitTest1.hpp"
#include "UnitTest2.hpp"
#include "UnitTest3.hpp"
#include "UnitTest4.hpp"
#include "UnitTest5.hpp"

#endif // CUCCA_UNITTESTS_UNITTESTS_HPP
