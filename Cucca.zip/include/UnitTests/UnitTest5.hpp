#ifndef CUCCA_UNITTESTS_UNITTEST5_HPP
#define CUCCA_UNITTESTS_UNITTEST5_HPP


#include "UnitTests.hpp"


#if CURRENT_TEST == 5


#include <iostream>


int unitTest(void);


#endif // CURRENT_TEST


#endif // CUCCA_UNITTESTS_UNITTEST5_HPP
