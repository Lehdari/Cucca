#ifndef CUCCA_UNITTESTS_UNITTEST3_HPP
#define CUCCA_UNITTESTS_UNITTEST3_HPP


#include "UnitTests.hpp"


#if CURRENT_TEST == 3


int unitTest(void);


#endif // CURRENT_TEST


#endif // CUCCA_UNITTESTS_UNITTEST3_HPP
